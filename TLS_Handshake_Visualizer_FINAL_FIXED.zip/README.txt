TLS Handshake Visualizer and Vulnerability Scanner
SINGLE INTEGRATED IMPLEMENTATION

The implementation extracts the server certificate with:
getpeercert(binary_form=True)
then converts DER -> PEM and decodes it with Python's SSL decoder.

It displays:
TLS version, cipher suite, cipher strength, certificate subject,
issuer, serial number, certificate version, validity dates, validity
status, SAN entries, hostname status, handshake stages, findings,
severity, security score, JSON report and HTML report.

Run:
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py

Open:
http://127.0.0.1:5000

Use only on systems you are authorized to test.
